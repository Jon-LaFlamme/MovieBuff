# MovieBuff:

A web application for finding TV/Film titles.

###Table of Contents

####A Overview

TODO:

####B Functionality

TODO:

####C Architecture

TODO:

####D Tech Stack

TODO:

####E Datasets

TODO:

####F Developer Guide

/devlogs/data-info/

    datasets-explored.pdf: output from jupyter notebook that checks info and head for several datasets

    IMDB-sets-descriptions.txt: Useful top-level description of all datasets downloaded from IMDB website 

    links-to-datasets.txt: All the candidate dataset source links copied from our project submission file

/devlogs/

    developer-guide.txt: Useful Flask links and local setup instructions

    phase-0-notes.txt: Logs detailing development steps taken to setup the application

    project-tasks-overview.txt: Sample outline of potential project phases and tasks

    streaming-services-api-info.txt: Some info about API services that show where you can stream a given title






